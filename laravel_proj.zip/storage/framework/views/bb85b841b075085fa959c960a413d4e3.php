<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Welcome to HackerPair</title>
</head>
<body>
<h1>Welcome to HackerPair</h1>
</body>
</html><?php /**PATH /home/alex/Desktop/laravel/resources/views/welcome.blade.php ENDPATH**/ ?>