<ul>
<?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($event); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<ul>
    <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <li><?php echo e($event); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <li>No events available.</li>
    <?php endif; ?>
</ul>

<ul>
    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <?php echo e($event); ?>

            <?php if(strpos($event,'ANDROID') !== false): ?>
                (sweet framework!)
                <?php elseif(strpos($event, 'Symphony') !== false): ?>
                    (Sweet symphony is an old framework)
                <?php else: ?>
                    (I am using Laravel)
            <?php endif; ?>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<img src="/img/tennis1.jpeg">
<img src="<?php echo e(asset('img/tennis1.jpeg')); ?>"><?php /**PATH /home/alex/Desktop/laravel/resources/views/events/index.blade.php ENDPATH**/ ?>